#include "Arduino.h"

#include "RGBLed.h"

const uint8_t RGBLed::RED[3] = {255, 0, 0};
const uint8_t RGBLed::GREEN[3] = {0, 255, 0};
const uint8_t RGBLed::BLUE[3] = {0, 0, 255};
const uint8_t RGBLed::MAGENTA[3] = {255, 0, 255};
const uint8_t RGBLed::CYAN[3] = {0, 255, 255};
const uint8_t RGBLed::YELLOW[3] = {255, 255, 0};
const uint8_t RGBLed::WHITE[3] = {255, 255, 255};

const bool RGBLed::COMMON_ANODE = true;
const bool RGBLed::COMMON_CATHODE = false;

RGBLed::RGBLed(uint8_t red, uint8_t green, uint8_t blue, bool common) : _red(red), _green(green), _blue(blue), _common(common), _brightness(100)
{
#if defined(ESP32)
  ledcSetup(0, 5000, 8);
  ledcSetup(1, 5000, 8);
  ledcSetup(2, 5000, 8);

  ledcAttachPin(_red, 0);
  ledcAttachPin(_green, 1);
  ledcAttachPin(_blue, 2);

#else
  pinMode(_red, OUTPUT);
  pinMode(_green, OUTPUT);
  pinMode(_blue, OUTPUT);
#endif
}

void RGBLed::off()
{
  color(0, 0, 0);
}

void RGBLed::brightness(const uint8_t rgb[3], uint8_t brightness)
{
  _brightness = brightness;
  intensity(rgb[0], rgb[1], rgb[2], brightness);
}

void RGBLed::brightness(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightness)
{
  _brightness = brightness;
  intensity(red, green, blue, brightness);
}

void RGBLed::brightness(uint8_t brightness)
{
  _brightness = brightness;
}

void RGBLed::intensity(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightness)
{
  if (brightness > 100)
    brightness = 100;

  red = (uint8_t)red * brightness / 100;
  green = (uint8_t)green * brightness / 100;
  blue = (uint8_t)blue * brightness / 100;
  color(red, green, blue);
}

void RGBLed::flash(const uint8_t rgb[3], uint16_t duration, uint8_t count = 1)
{
  blink(rgb[0], rgb[1], rgb[2], duration, duration, count);
}

void RGBLed::flash(const uint8_t rgb[3], uint16_t onDuration, uint16_t duration, uint8_t count = 1)
{
  blink(rgb[0], rgb[1], rgb[2], onDuration, duration, count);
}

void RGBLed::flash(uint8_t red, uint8_t green, uint8_t blue, uint16_t duration, uint8_t count = 1)
{
  blink(red, green, blue, duration, duration, count);
}

void RGBLed::flash(uint8_t red, uint8_t green, uint8_t blue, uint16_t onDuration, uint16_t duration, uint8_t count = 1)
{
  blink(red, green, blue, onDuration, duration, count);
}

void RGBLed::blink(uint8_t red, uint8_t green, uint8_t blue, uint16_t onDuration, uint16_t duration, uint8_t count = 1)
{

  if (count < 1)
    count = 1;

  for (uint8_t i = 0; i < count; i++) {
    intensity(red, green, blue, _brightness);
    delay(onDuration);
    off();
    delay(duration);  // Always delay, even after the last blink
  }
}

void RGBLed::setColor(const uint8_t rgb[3])
{
  intensity(rgb[0], rgb[1], rgb[2], _brightness);
}

void RGBLed::setColor(uint8_t red, uint8_t green, uint8_t blue)
{
  intensity(red, green, blue, _brightness);
}

void RGBLed::color(uint8_t red, uint8_t green, uint8_t blue)
{
  if (red > 255) red = 255;
  if (green > 255) green = 255;
  if (blue > 255) blue = 255;

  if (_common == COMMON_ANODE)
  {
#if defined(ESP32)
    ledcWrite(0, 255 - red);
    ledcWrite(1, 255 - green);
    ledcWrite(2, 255 - blue);
#else
    analogWrite(_red, 255 - red);
    analogWrite(_green, 255 - green);
    analogWrite(_blue, 255 - blue);
#endif
  }
  else
  {
#if defined(ESP32)
    ledcWrite(0, red);
    ledcWrite(1, green);
    ledcWrite(2, blue);
#else
    analogWrite(_red, red);
    analogWrite(_green, green);
    analogWrite(_blue, blue);
#endif
  }
}

void RGBLed::fadeOut(const uint8_t rgb[3], uint8_t steps, uint16_t duration)
{
  fade(rgb[0], rgb[1], rgb[2], steps, duration, true);
}

void RGBLed::fadeOut(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration)
{
  fade(red, green, blue, steps, duration, true);
}

void RGBLed::fadeIn(const uint8_t rgb[3], uint8_t steps, uint16_t duration)
{
  fade(rgb[0], rgb[1], rgb[2], steps, duration, false);
}

void RGBLed::fadeIn(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration)
{
  fade(red, green, blue, steps, duration, false);
}

void RGBLed::fade(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration, bool out)
{
  if (steps < 1)
    steps = 1;

  if (out)
  {
    for (uint16_t i = steps; i != 65535; i--)  /* i >= 0 as uint16_t */
    {
      uint8_t val = (uint8_t)i * 255 / steps;
      fade(red, green, blue, steps, duration, val, (i > 0));
    }
  }
  else
  {
    for (uint16_t i = 0; i <= steps; i++)
    {
      uint8_t val = (uint8_t)i * 255 / steps;
      fade(red, green, blue, steps, duration, val, (i < steps));
    }
  }
}

void RGBLed::fade(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration, uint16_t value, bool wait)
{
  /* Integer scaling: value is 0..255, avoid float */
  uint8_t r = (uint8_t)red * value / 255;
  uint8_t g = (uint8_t)green * value / 255;
  uint8_t b = (uint8_t)blue * value / 255;
  intensity(r, g, b, _brightness);

  if (wait && steps > 0)
  {
    delay((unsigned long)(duration / steps));
  }
}

void RGBLed::crossFade(const uint8_t rgbFrom[3], const uint8_t rgbTo[3], uint8_t steps, uint16_t duration)
{
  crossFade(rgbFrom[0], rgbFrom[1], rgbFrom[2], rgbTo[0], rgbTo[1], rgbTo[2], steps, duration);
}

void RGBLed::crossFade(uint8_t fromRed, uint8_t fromGreen, uint8_t fromBlue, uint8_t toRed, uint8_t toGreen, uint8_t toBlue, uint8_t steps, uint16_t duration)
{
  if (steps == 0) steps = 1;
  int16_t deltaRed = (int16_t)toRed - (int16_t)fromRed;
  int16_t deltaGreen = (int16_t)toGreen - (int16_t)fromGreen;
  int16_t deltaBlue = (int16_t)toBlue - (int16_t)fromBlue;

  int16_t changeRed = (deltaRed << 8) / (int16_t)steps;
  int16_t changeGreen = (deltaGreen << 8) / (int16_t)steps;
  int16_t changeBlue = (deltaBlue << 8) / (int16_t)steps;

  for (uint16_t i = 0; i <= steps; i++)
  {
    int32_t r = (int32_t)fromRed + ((int32_t)changeRed * (int32_t)i >> 8);
    int32_t g = (int32_t)fromGreen + ((int32_t)changeGreen * (int32_t)i >> 8);
    int32_t b = (int32_t)fromBlue + ((int32_t)changeBlue * (int32_t)i >> 8);
    if (r < 0) r = 0; else if (r > 255) r = 255;
    if (g < 0) g = 0; else if (g > 255) g = 255;
    if (b < 0) b = 0; else if (b > 255) b = 255;
    intensity((uint8_t)r, (uint8_t)g, (uint8_t)b, _brightness);

    if (i < steps)
      delay((unsigned long)(duration / steps));
  }
}

void RGBLed::gradient(const uint8_t rgbFrom[3], const uint8_t rgbTo[3], uint8_t step)
{
  gradient(rgbFrom[0], rgbFrom[1], rgbFrom[2], rgbTo[0], rgbTo[1], rgbTo[2], step);
}

void RGBLed::gradient(uint8_t fromRed, uint8_t fromGreen, uint8_t fromBlue, uint8_t toRed, uint8_t toGreen, uint8_t toBlue, uint8_t step)
{
  int16_t deltaRed = (int16_t)toRed - (int16_t)fromRed;
  int16_t deltaGreen = (int16_t)toGreen - (int16_t)fromGreen;
  int16_t deltaBlue = (int16_t)toBlue - (int16_t)fromBlue;

  int32_t r = (int32_t)fromRed + (int32_t)deltaRed * step / 255;
  int32_t g = (int32_t)fromGreen + (int32_t)deltaGreen * step / 255;
  int32_t b = (int32_t)fromBlue + (int32_t)deltaBlue * step / 255;
  if (r < 0) r = 0; else if (r > 255) r = 255;
  if (g < 0) g = 0; else if (g > 255) g = 255;
  if (b < 0) b = 0; else if (b > 255) b = 255;
  intensity((uint8_t)r, (uint8_t)g, (uint8_t)b, _brightness);
}
