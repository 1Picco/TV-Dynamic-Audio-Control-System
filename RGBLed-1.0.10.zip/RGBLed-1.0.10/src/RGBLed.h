#ifndef RGBLed_h
#define RGBLed_h

#include "Arduino.h"

class RGBLed
{

public:
	RGBLed(uint8_t red, uint8_t green, uint8_t blue, bool common);

	void off();

	void brightness(const uint8_t rgb[3], uint8_t brightness);
	void brightness(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightness);
	void brightness(uint8_t brightness);

        void flash(const uint8_t rgb[3], uint16_t duration, uint8_t count = 1);
        void flash(const uint8_t rgb[3], uint16_t onDuration, uint16_t duration, uint8_t count = 1);
        void flash(uint8_t red, uint8_t green, uint8_t blue, uint16_t duration, uint8_t count = 1);
        void flash(uint8_t red, uint8_t green, uint8_t blue, uint16_t onDuration, uint16_t duration, uint8_t count = 1);

	void setColor(const uint8_t rgb[3]);
	void setColor(uint8_t red, uint8_t green, uint8_t blue);

	void fadeOut(const uint8_t rgb[3], uint8_t steps, uint16_t duration);
	void fadeOut(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration);

	void fadeIn(const uint8_t rgb[3], uint8_t steps, uint16_t duration);
	void fadeIn(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration);

	void crossFade(const uint8_t rgbFrom[3], const uint8_t rgbTo[3], uint8_t steps, uint16_t duration);
	void crossFade(uint8_t fromRed, uint8_t fromGreen, uint8_t fromBlue, uint8_t toRed, uint8_t toGreen, uint8_t toBlue, uint8_t steps, uint16_t duration);
	
	void gradient(const uint8_t rgbFrom[3], const uint8_t rgbTo[3], uint8_t step);
	void gradient(uint8_t fromRed, uint8_t fromGreen, uint8_t fromBlue, uint8_t toRed, uint8_t toGreen, uint8_t toBlue, uint8_t step);

	static const uint8_t RED[3];
	static const uint8_t GREEN[3];
	static const uint8_t BLUE[3];
	static const uint8_t MAGENTA[3];
	static const uint8_t CYAN[3];
	static const uint8_t YELLOW[3];
	static const uint8_t WHITE[3];

	static const bool COMMON_ANODE;
	static const bool COMMON_CATHODE;

private:
	uint8_t _red, _green, _blue, _brightness;
	bool _common;
	void color(uint8_t red, uint8_t green, uint8_t blue);
	void blink(uint8_t red, uint8_t green, uint8_t blue, uint16_t onDuration, uint16_t duration, uint8_t count = 1);
	void intensity(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightness);
	void fade(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration, bool out);
	void fade(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration, uint16_t value, bool wait);
};

#endif
