/*
 * RGBLed Library
 * Original Copyright (c) wilmouths (https://github.com/wilmouths/RGBLed.git)
 *
 * Modified by Attila on September 11, 2026:
 * - Converted RGB color constants and pin parameters to uint8_t
 * - Replaced floating-point arithmetic with fixed-point/integer arithmetic
 * - Added multi-flash count support to flash()
 * - Added protection against zero-step fades and out-of-bounds RGB values
 *
 * Licensed under the GNU General Public License v3.0.
 */

#include "Arduino.h"
#include "RGBLed.h"

const uint8_t RGBLed::RED[3] = {255, 0, 0};
const uint8_t RGBLed::GREEN[3] = {0, 255, 0};
const uint8_t RGBLed::BLUE[3] = {0, 0, 255};
const uint8_t RGBLed::MAGENTA[3] = {255, 0, 255};
const uint8_t RGBLed::CYAN[3] = {0, 255, 255};
const uint8_t RGBLed::YELLOW[3] = {255, 255, 0};
const uint8_t RGBLed::WHITE[3] = {255, 255, 255};

const bool RGBLed::COMMON_ANODE = true;
const bool RGBLed::COMMON_CATHODE = false;

RGBLed::RGBLed(uint8_t red, uint8_t green, uint8_t blue, bool common) 
    : _red(red), _green(green), _blue(blue), _common(common), _brightness(100)
{
#if defined(ESP32)
  ledcSetup(0, 5000, 8);
  ledcSetup(1, 5000, 8);
  ledcSetup(2, 5000, 8);

  ledcAttachPin(_red, 0);
  ledcAttachPin(_green, 1);
  ledcAttachPin(_blue, 2);
#else
  pinMode(_red, OUTPUT);
  pinMode(_green, OUTPUT);
  pinMode(_blue, OUTPUT);
#endif
}

void RGBLed::off()
{
  color(0, 0, 0);
}

// --- Brightness Overloads ---
void RGBLed::brightness(const uint8_t rgb[3], uint8_t brightnessVal)
{
  brightness(rgb[0], rgb[1], rgb[2], brightnessVal);
}

void RGBLed::brightness(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightnessVal)
{
  _brightness = brightnessVal;
  intensity(red, green, blue, brightnessVal);
}

void RGBLed::brightness(uint8_t brightnessVal)
{
  _brightness = brightnessVal;
}

void RGBLed::intensity(uint8_t red, uint8_t green, uint8_t blue, uint8_t brightnessVal)
{
  if (brightnessVal > 100) brightnessVal = 100;

  color((uint16_t)red * brightnessVal / 100,
        (uint16_t)green * brightnessVal / 100,
        (uint16_t)blue * brightnessVal / 100);
}

// --- Flash Overloads ---
void RGBLed::flash(const uint8_t rgb[3], uint16_t duration, uint8_t count)
{
  blink(rgb[0], rgb[1], rgb[2], duration, duration, count);
}

void RGBLed::flash(const uint8_t rgb[3], uint8_t onDuration, uint16_t duration, uint8_t count)
{
  blink(rgb[0], rgb[1], rgb[2], onDuration, duration, count);
}

void RGBLed::flash(uint8_t red, uint8_t green, uint8_t blue, uint16_t duration, uint8_t count)
{
  blink(red, green, blue, duration, duration, count);
}

void RGBLed::flash(uint8_t red, uint8_t green, uint8_t blue, uint8_t onDuration, uint16_t duration, uint8_t count)
{
  blink(red, green, blue, onDuration, duration, count);
}

void RGBLed::blink(uint8_t red, uint8_t green, uint8_t blue, uint8_t onDuration, uint16_t duration, uint8_t count)
{
  if (count < 1) count = 1;

  for (uint8_t i = 0; i < count; i++) {
    intensity(red, green, blue, _brightness);
    delay(onDuration);
    color(0, 0, 0);
    delay(duration);
  }
}

// --- SetColor Overloads ---
void RGBLed::setColor(const uint8_t rgb[3])
{
  intensity(rgb[0], rgb[1], rgb[2], _brightness);
}

void RGBLed::setColor(uint8_t red, uint8_t green, uint8_t blue)
{
  intensity(red, green, blue, _brightness);
}

void RGBLed::color(uint8_t red, uint8_t green, uint8_t blue)
{
  if (_common == COMMON_ANODE)
  {
#if defined(ESP32)
    ledcWrite(0, 255 - red);
    ledcWrite(1, 255 - green);
    ledcWrite(2, 255 - blue);
#else
    analogWrite(_red, 255 - red);
    analogWrite(_green, 255 - green);
    analogWrite(_blue, 255 - blue);
#endif
  }
  else
  {
#if defined(ESP32)
    ledcWrite(0, red);
    ledcWrite(1, green);
    ledcWrite(2, blue);
#else
    analogWrite(_red, red);
    analogWrite(_green, green);
    analogWrite(_blue, blue);
#endif
  }
}

// --- Fade / FadeOut / FadeIn Overloads ---
void RGBLed::fadeOut(const uint8_t rgb[3], uint8_t steps, uint16_t duration)
{
  fade(rgb[0], rgb[1], rgb[2], steps, duration, true);
}

void RGBLed::fadeOut(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration)
{
  fade(red, green, blue, steps, duration, true);
}

void RGBLed::fadeIn(const uint8_t rgb[3], uint8_t steps, uint16_t duration)
{
  fade(rgb[0], rgb[1], rgb[2], steps, duration, false);
}

void RGBLed::fadeIn(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration)
{
  fade(red, green, blue, steps, duration, false);
}

void RGBLed::fade(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration, bool out)
{
  if (steps < 1) steps = 1;

  for (uint8_t i = 0; i <= steps; i++)
  {
    uint8_t currentStep = out ? (steps - i) : i;
    uint8_t val = (uint16_t)currentStep * 255 / steps;
    
    fade(red, green, blue, steps, duration, val, (i < steps));
  }
}

void RGBLed::fade(uint8_t red, uint8_t green, uint8_t blue, uint8_t steps, uint16_t duration, uint16_t value, bool wait)
{
  uint8_t r = (uint16_t)red * value / 255;
  uint8_t g = (uint16_t)green * value / 255;
  uint8_t b = (uint16_t)blue * value / 255;
  intensity(r, g, b, _brightness);

  if (wait && steps > 0)
  {
    delay(duration / steps);
  }
}

// --- CrossFade Overloads ---
void RGBLed::crossFade(const uint8_t rgbFrom[3], const uint8_t rgbTo[3], uint8_t steps, uint16_t duration)
{
  crossFade(rgbFrom[0], rgbFrom[1], rgbFrom[2], rgbTo[0], rgbTo[1], rgbTo[2], steps, duration);
}

void RGBLed::crossFade(uint8_t fromRed, uint8_t fromGreen, uint8_t fromBlue, uint8_t toRed, uint8_t toGreen, uint8_t toBlue, uint8_t steps, uint16_t duration)
{
  if (steps == 0) steps = 1;
  
  int16_t deltaRed = (int16_t)toRed - fromRed;
  int16_t deltaGreen = (int16_t)toGreen - fromGreen;
  int16_t deltaBlue = (int16_t)toBlue - fromBlue;

  for (uint16_t i = 0; i <= steps; i++)
  {
    uint8_t r = fromRed + ((int32_t)deltaRed * i) / steps;
    uint8_t g = fromGreen + ((int32_t)deltaGreen * i) / steps;
    uint8_t b = fromBlue + ((int32_t)deltaBlue * i) / steps;
    
    intensity(r, g, b, _brightness);

    if (i < steps)
      delay(duration / steps);
  }
}

// --- Gradient Overloads ---
void RGBLed::gradient(const uint8_t rgbFrom[3], const uint8_t rgbTo[3], uint8_t step)
{
  gradient(rgbFrom[0], rgbFrom[1], rgbFrom[2], rgbTo[0], rgbTo[1], rgbTo[2], step);
}

void RGBLed::gradient(uint8_t fromRed, uint8_t fromGreen, uint8_t fromBlue, uint8_t toRed, uint8_t toGreen, uint8_t toBlue, uint8_t step)
{
  int16_t deltaRed = (int16_t)toRed - fromRed;
  int16_t deltaGreen = (int16_t)toGreen - fromGreen;
  int16_t deltaBlue = (int16_t)toBlue - fromBlue;

  uint8_t r = fromRed + ((int32_t)deltaRed * step) / 255;
  uint8_t g = fromGreen + ((int32_t)deltaGreen * step) / 255;
  uint8_t b = fromBlue + ((int32_t)deltaBlue * step) / 255;
  
  intensity(r, g, b, _brightness);
}